-- Serpentia online schema for Supabase PostgreSQL
-- Paste into Supabase Dashboard -> SQL Editor -> New query and run.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique check (char_length(username) between 3 and 20),
  bio text not null default '' check (char_length(bio) <= 240),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.game_saves (
  user_id uuid primary key references auth.users(id) on delete cascade,
  save_data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.friendships (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references auth.users(id) on delete cascade,
  addressee_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending' check (status in ('pending','accepted','declined','blocked')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (requester_id <> addressee_id),
  unique (requester_id, addressee_id)
);

create index if not exists friendships_addressee_idx on public.friendships(addressee_id, status);
create index if not exists friendships_requester_idx on public.friendships(requester_id, status);

alter table public.profiles enable row level security;
alter table public.game_saves enable row level security;
alter table public.friendships enable row level security;

-- Public profile names are visible to the community; players can only edit their own profile.
drop policy if exists "profiles readable by everyone" on public.profiles;
create policy "profiles readable by everyone" on public.profiles
for select to anon, authenticated using (true);
drop policy if exists "users create own profile" on public.profiles;
create policy "users create own profile" on public.profiles
for insert to authenticated with check ((select auth.uid()) = id);
drop policy if exists "users update own profile" on public.profiles;
create policy "users update own profile" on public.profiles
for update to authenticated using ((select auth.uid()) = id) with check ((select auth.uid()) = id);

-- Saves are private: only their owner can read/write.
drop policy if exists "owner reads own save" on public.game_saves;
create policy "owner reads own save" on public.game_saves
for select to authenticated using ((select auth.uid()) = user_id);
drop policy if exists "owner creates own save" on public.game_saves;
create policy "owner creates own save" on public.game_saves
for insert to authenticated with check ((select auth.uid()) = user_id);
drop policy if exists "owner updates own save" on public.game_saves;
create policy "owner updates own save" on public.game_saves
for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

-- Only participants can view a friendship; requester can create it.
drop policy if exists "participants view friendships" on public.friendships;
create policy "participants view friendships" on public.friendships
for select to authenticated using ((select auth.uid()) = requester_id or (select auth.uid()) = addressee_id);
drop policy if exists "users request friendship" on public.friendships;
create policy "users request friendship" on public.friendships
for insert to authenticated with check ((select auth.uid()) = requester_id and status = 'pending');
drop policy if exists "recipient responds to friendship" on public.friendships;
create policy "recipient responds to friendship" on public.friendships
for update to authenticated using ((select auth.uid()) = addressee_id) with check ((select auth.uid()) = addressee_id and status in ('accepted','declined','blocked'));
drop policy if exists "requester cancels friendship" on public.friendships;
create policy "requester cancels friendship" on public.friendships
for delete to authenticated using ((select auth.uid()) = requester_id);

grant select on public.profiles to anon, authenticated;
grant insert, update on public.profiles to authenticated;
grant select, insert, update on public.game_saves to authenticated;
grant select, insert, update, delete on public.friendships to authenticated;
