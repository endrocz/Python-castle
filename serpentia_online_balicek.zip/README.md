# Serpentia – online deployment starter

Tento balíček obsahuje hratelnou HTML hru, napojení na Supabase Auth a databázi pro cloudové ukládání, veřejné profily a žádosti o přátelství.

## Důležité, než začneš
Nemohu vytvořit hosting ani databázi ve tvém jméně bez přihlášení a výslovného přístupu k tvým účtům. Balíček je připravený pro nasazení, ale veřejná URL a online účty začnou fungovat až po založení projektu a vložení jeho URL/klíče. Nikdy mi neposílej heslo ani tajné klíče.

## 1. Vytvoř backend (Supabase)
1. Otevři https://supabase.com/ a vytvoř účet/projekt.
2. V projektu otevři **SQL Editor → New query**.
3. Vlož celý obsah souboru `supabase_schema.sql` a spusť ho.
4. Otevři **Project Settings → API** (nebo Connect podle aktuálního rozhraní).
5. Zkopíruj **Project URL** a veřejný **publishable key** (u starších projektů se může jmenovat `anon` key). Nikdy nepoužívej `service_role` / secret key ve frontendu.

## 2. Propoj web s backendem
1. Otevři `index.html` v textovém editoru.
2. Najdi:
   `window.SERPENTIA_SUPABASE_URL = "PASTE_SUPABASE_PROJECT_URL_HERE";`
   `window.SERPENTIA_SUPABASE_ANON_KEY = "PASTE_SUPABASE_PUBLISHABLE_KEY_HERE";`
3. Nahraď zástupné texty svou Project URL a publishable/anon key.
4. V Supabase Authentication → URL Configuration nastav Site URL a Redirect URLs na adresu webu, kterou získáš v dalším kroku. Pro první test lze dočasně použít localhost, ale produkční doménu nastav před sdílením.

## 3. Publikuj veřejný web zdarma
Nejjednodušší cesta pro čisté HTML je Cloudflare Pages:
1. Vytvoř si účet na https://github.com/ a založ nový privátní nebo veřejný repozitář `serpentia`.
2. Nahraj do kořene repozitáře soubor `index.html`. (Soubor `supabase_schema.sql` můžeš nahrát také pro zálohu; README není nutné.)
3. Otevři https://dash.cloudflare.com/ → **Workers & Pages** → **Create** → **Pages** → připoj GitHub repozitář.
4. Pro čisté HTML zvol bez frameworku / Static HTML. Build command: `exit 0`. Output directory: `/` nebo adresář, ve kterém je `index.html`, dle aktuálního průvodce.
5. Po dokončení získáš adresu typu `https://nazev-projektu.pages.dev`.
6. Přidej tuto adresu do Supabase Auth URL Configuration a proveď test registrace/přihlášení z veřejné adresy.

Oficiální návody:
- Supabase Auth: https://supabase.com/docs/guides/auth
- Supabase Row Level Security: https://supabase.com/docs/guides/database/postgres/row-level-security
- Cloudflare Pages pro statické HTML: https://developers.cloudflare.com/pages/framework-guides/deploy-anything/

## Co je v této verzi
- Samostatná hra fungující i offline.
- Supabase e-mail/heslo registrace a přihlášení po nakonfigurování klíčů.
- Databázové tabulky pro profily, soukromé uložené hry a žádosti o přátelství.
- Základní seznam veřejných profilů a odesílání žádosti o přátelství.

## Co není hotové / musí se doprogramovat před větší komunitou
- Produkční testy na skutečném nasazení a mobilních prohlížečích.
- Přijímání/odmítání žádostí o přátelství v UI, seznam přátel.
- Chat, návštěvy terárií, moderace, blokování uživatelů a hlášení.
- Serverová validace herní ekonomiky proti podvádění. V této prototypové verzi je herní stav z klienta, takže není bezpečný pro soutěžní žebříčky nebo obchod s hodnotnými předměty.
- Obnova hesla a ověření e-mailu je třeba doladit v nastavení Supabase Auth a otestovat.

## Bezpečnost
- `publishable` / `anon` klíč je určen pro frontend pouze při správných RLS pravidlech.
- Nikdy nevkládej `service_role`, secret key, DB heslo ani soukromé tokeny do `index.html`.
- Schéma používá RLS a soukromé pravidlo pro herní save. Zkontroluj policy při jakékoliv změně tabulek.
